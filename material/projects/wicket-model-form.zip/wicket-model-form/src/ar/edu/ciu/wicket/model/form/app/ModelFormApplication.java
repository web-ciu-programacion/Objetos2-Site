package ar.edu.ciu.wicket.model.form.app;

import org.apache.wicket.Page;
import org.apache.wicket.protocol.http.WebApplication;

import ar.edu.ciu.wicket.model.form.useCase.persona.PersonaWeb;

public class ModelFormApplication extends WebApplication {

	@Override
	public Class<? extends Page> getHomePage() {
		return PersonaWeb.class;
	}

}
