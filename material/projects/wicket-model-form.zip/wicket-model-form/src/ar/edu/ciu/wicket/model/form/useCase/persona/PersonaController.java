package ar.edu.ciu.wicket.model.form.useCase.persona;

import java.util.List;

import ar.edu.ciu.wicket.model.form.domain.Persona;
import ar.edu.ciu.wicket.model.form.store.ModelFormStore;

public class PersonaController {

		// metodos
	public List<Persona> getPersonas() {
		return ModelFormStore.getInstance().getPersonas();
	}

	public void agregarPersona(String nombre, String apellido, String sexo) {
			Persona nuevaPersona = new Persona(nombre, apellido, sexo);
			ModelFormStore.getInstance().add(nuevaPersona);
	}

}
