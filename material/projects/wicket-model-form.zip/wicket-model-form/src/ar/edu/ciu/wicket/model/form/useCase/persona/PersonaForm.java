package ar.edu.ciu.wicket.model.form.useCase.persona;

import java.util.Arrays;
import java.util.List;

import org.apache.wicket.Component;
import org.apache.wicket.feedback.ExactLevelFeedbackMessageFilter;
import org.apache.wicket.feedback.FeedbackMessage;
import org.apache.wicket.markup.html.form.DropDownChoice;
import org.apache.wicket.markup.html.form.Form;
import org.apache.wicket.markup.html.form.TextField;
import org.apache.wicket.markup.html.panel.FeedbackPanel;
import org.apache.wicket.model.CompoundPropertyModel;
import org.apache.wicket.model.IModel;

public class PersonaForm extends Form<PersonaForm> {

		// constantes
	private static final long serialVersionUID = -879283243976969661L;

		// atributos
	private String nombre;
	private String apellido;
	private String sexo;
	private PersonaController controller;

		// constructor
	public PersonaForm(String id) {
		super(id);
		this.controller = new PersonaController();
		IModel<PersonaForm> model = new CompoundPropertyModel<>(this);
		this.setDefaultModel(model);
		List<String> sexos = Arrays.asList("femenino", "masculino");
		this.add(this.getNombreField());
		this.add(new TextField<>("apellido"));
		this.add(new DropDownChoice<>("sexo", sexos));
		this.add(new FeedbackPanel("feedbackMessage", new ExactLevelFeedbackMessageFilter(FeedbackMessage.ERROR)));
	}

		// metodos
	private Component getNombreField() {
		TextField<String> nombreField = new TextField<>("nombre");
		nombreField.setRequired(true);
		return nombreField;
	}

	@Override
	protected void onSubmit() {
		this.controller.agregarPersona(this.nombre, this.apellido, this.sexo);
		this.setResponsePage(PersonaWeb.class);
	}

		// gets y sets
	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getApellido() {
		return apellido;
	}

	public void setApellido(String apellido) {
		this.apellido = apellido;
	}

	public String getSexo() {
		return sexo;
	}

	public void setSexo(String sexo) {
		this.sexo = sexo;
	}

}
