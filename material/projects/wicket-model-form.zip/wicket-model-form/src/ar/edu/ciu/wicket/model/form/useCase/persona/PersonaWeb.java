package ar.edu.ciu.wicket.model.form.useCase.persona;

import org.apache.wicket.markup.html.WebPage;
import org.apache.wicket.markup.html.basic.Label;
import org.apache.wicket.markup.html.list.ListItem;
import org.apache.wicket.markup.html.list.ListView;
import org.apache.wicket.model.PropertyModel;

import ar.edu.ciu.wicket.model.form.domain.Persona;

public class PersonaWeb extends WebPage {

		// constantes
	private static final long serialVersionUID = 4448199978748094124L;

		// atributos
	private PersonaController controller;

		// constructor
	public PersonaWeb() {
		super();
		this.controller = new PersonaController();
		// agrego ListView a la WebPage
		this.add(new ListView<Persona>("personas", this.controller.getPersonas()) {
				private static final long serialVersionUID = 1L;
				@Override
				protected void populateItem(ListItem<Persona> item) {
					item.add(new Label("nombre", new PropertyModel<String>(item.getModel(), "nombre")));
					item.add(new Label("apellido", new PropertyModel<String>(item.getModel(), "apellido")));
					item.add(new Label("sexo", new PropertyModel<String>(item.getModel(), "sexo")));
				}
		});
		// agrego Form a la WebPage
		this.add(new PersonaForm("formPersona"));
	}

}
