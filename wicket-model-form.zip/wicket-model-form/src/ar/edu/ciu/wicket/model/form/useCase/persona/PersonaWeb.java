package ar.edu.ciu.wicket.model.form.useCase.persona;

import org.apache.wicket.markup.html.WebPage;
import org.apache.wicket.markup.html.basic.Label;
import org.apache.wicket.markup.html.list.ListItem;
import org.apache.wicket.markup.html.list.ListView;
import org.apache.wicket.model.PropertyModel;
import org.apache.wicket.request.mapper.parameter.PageParameters;

import ar.edu.ciu.wicket.model.form.domain.Persona;
import ar.edu.ciu.wicket.model.form.store.ModelFormStore;

public class PersonaWeb extends WebPage {

		// constantes
	private static final long serialVersionUID = 4448199978748094124L;

		// constructor
	public PersonaWeb(PageParameters parameters) {
		super(parameters);
		// verifico si viene del submit
		if (parameters.get("nombre").toString()!=null) {
			Persona nuevaPersona = new Persona(
								parameters.get("nombre").toString(), 
								parameters.get("apellido").toString(), 
								parameters.get("sexo").toString());
			ModelFormStore.getInstance().add(nuevaPersona);
		}
		// agrego ListView a la WebPage
		this.add(new ListView<Persona>("personas", ModelFormStore.getInstance().getPersonas()) {
				private static final long serialVersionUID = 1L;
				@Override
				protected void populateItem(ListItem<Persona> item) {
					item.add(new Label("nombre", new PropertyModel<String>(item.getModel(), "nombre")));
					item.add(new Label("apellido", new PropertyModel<String>(item.getModel(), "apellido")));
					item.add(new Label("sexo", new PropertyModel<String>(item.getModel(), "sexo")));
				}
		});
		// agrego Form a la WebPage
		add(new PersonaForm("formPersona"));
	}

}
