package ar.edu.ciu.wicket.model.form.useCase.persona;

import java.util.Arrays;
import java.util.List;

import org.apache.wicket.Component;
import org.apache.wicket.feedback.ExactLevelFeedbackMessageFilter;
import org.apache.wicket.feedback.FeedbackMessage;
import org.apache.wicket.markup.html.form.DropDownChoice;
import org.apache.wicket.markup.html.form.Form;
import org.apache.wicket.markup.html.form.TextField;
import org.apache.wicket.markup.html.panel.FeedbackPanel;
import org.apache.wicket.model.CompoundPropertyModel;
import org.apache.wicket.model.IModel;
import org.apache.wicket.request.mapper.parameter.PageParameters;

public class PersonaForm extends Form<PersonaForm> {

		// constantes
	private static final long serialVersionUID = -879283243976969661L;

		// atributos
	private String nombre;
	private String apellido;
	private String sexo;

		// constructor
	public PersonaForm(String id) {
		super(id);

		IModel<PersonaForm> model = new CompoundPropertyModel<>(this);
		super.setDefaultModel(model);

		List<String> sexos = Arrays.asList("femenino", "masculino");

		super.add(this.getNombreField());
		super.add(new TextField<>("apellido"));
		super.add(new DropDownChoice<>("sexo", sexos));
		super.add(new FeedbackPanel("feedbackMessage", new ExactLevelFeedbackMessageFilter(FeedbackMessage.ERROR)));
	}

	private Component getNombreField() {
		TextField<String> nombreField = new TextField<>("nombre");
		nombreField.setRequired(true);
		return nombreField;
	}

	@Override
	protected void onSubmit() {
		this.success("El nombre es correcto!");
		PageParameters pageParameters = new PageParameters();
		pageParameters.add("nombre", this.nombre);
		pageParameters.add("apellido", this.apellido);
		pageParameters.add("sexo", this.sexo);
		this.setResponsePage(PersonaWeb.class, pageParameters);
	}

		// gets y sets
	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getApellido() {
		return apellido;
	}

	public void setApellido(String apellido) {
		this.apellido = apellido;
	}

	public String getSexo() {
		return sexo;
	}

	public void setSexo(String sexo) {
		this.sexo = sexo;
	}

}
