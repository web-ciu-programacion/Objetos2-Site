package ar.edu.ciu.wicket.model.form.store;

import java.util.ArrayList;
import java.util.List;

import ar.edu.ciu.wicket.model.form.domain.Persona;

public class ModelFormStore {

	private static ModelFormStore instance;

	private List<Persona> personas;

	private ModelFormStore() {
		super();
		this.fill();
	}

	public static ModelFormStore getInstance() {
		if (instance==null)
			instance = new ModelFormStore();
		return instance;
	}

	public void add(Persona persona) {
		this.personas.add(persona);
	}

	public List<Persona> getPersonas() {
		return this.personas;
	}

	private void fill() {
		this.personas = new ArrayList<>();
		Persona persona = new Persona("Mariano", "Moreno", "Masculino");
		this.personas.add(persona);
	}

}
